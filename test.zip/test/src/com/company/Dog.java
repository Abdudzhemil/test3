package com.company;

  class Dog extends Animal{
     public void sleep(){
         System.out.println("Dog sleeping");
     }
    public void bark(){
        System.out.println("I am, BARKING");
    }

}
